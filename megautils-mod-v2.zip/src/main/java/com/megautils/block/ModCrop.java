package com.megautils.block;

import java.util.function.Supplier;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.CropBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;

/** Культура с 4 стадиями роста (возраст 0..3). */
public class ModCrop extends CropBlock {
    public static final IntProperty AGE3 = Properties.AGE_3;
    private final Supplier<Item> seeds;

    public ModCrop(Settings settings, Supplier<Item> seeds) {
        super(settings);
        this.seeds = seeds;
    }

    @Override
    public IntProperty getAgeProperty() { return AGE3; }

    @Override
    public int getMaxAge() { return 3; }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE3);
    }

    @Override
    protected ItemConvertible getSeedsItem() { return seeds.get(); }
}
