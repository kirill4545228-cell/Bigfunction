package com.megautils.block;

import com.megautils.MegaUtils;
import com.megautils.item.ModItems;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;

public final class ModBlocks {
    public static final Block HEALING_BLOCK = reg("healing_block", new HealingBlock(
            FabricBlockSettings.create().strength(3.0f, 6.0f).requiresTool().luminance(s -> 8)
                    .sounds(BlockSoundGroup.AMETHYST_BLOCK)));

    public static final Block METEORITE_ORE = reg("meteorite_ore", new Block(
            FabricBlockSettings.create().strength(4.0f, 6.0f).requiresTool().luminance(s -> 4)
                    .sounds(BlockSoundGroup.STONE)));

    public static final Block LUMIBERRY_CROP = reg("lumiberry_crop", new ModCrop(
            FabricBlockSettings.copyOf(Blocks.WHEAT).luminance(s -> 3 + 3 * s.get(Properties.AGE_3)),
            () -> ModItems.LUMIBERRY_SEEDS));
    public static final Block EMBER_PEPPER_CROP = reg("ember_pepper_crop", new ModCrop(
            FabricBlockSettings.copyOf(Blocks.WHEAT), () -> ModItems.EMBER_PEPPER_SEEDS));
    public static final Block FROST_MINT_CROP = reg("frost_mint_crop", new ModCrop(
            FabricBlockSettings.copyOf(Blocks.WHEAT), () -> ModItems.FROST_MINT_SEEDS));

    private static Block reg(String name, Block b) {
        return Registry.register(Registries.BLOCK, new Identifier(MegaUtils.MODID, name), b);
    }

    public static void init() { }
}
