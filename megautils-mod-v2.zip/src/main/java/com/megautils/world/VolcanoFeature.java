package com.megautils.world;

import com.mojang.serialization.Codec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/**
 * Вулкан: конус из базальта с лавовым кратером, внутри — пещера с монстрами и боссом «Хранитель вулкана».
 * Убей босса — на его месте появится сундук с наградой (см. WorldEvents).
 */
public class VolcanoFeature extends Feature<DefaultFeatureConfig> {
    public static final String BOSS_TAG = "megautils_boss";

    public VolcanoFeature(Codec<DefaultFeatureConfig> codec) { super(codec); }

    private static BlockState pick(Random r) {
        float f = r.nextFloat();
        if (f < 0.45f) return Blocks.BLACKSTONE.getDefaultState();
        if (f < 0.78f) return Blocks.BASALT.getDefaultState();
        if (f < 0.88f) return Blocks.SMOOTH_BASALT.getDefaultState();
        if (f < 0.95f) return Blocks.MAGMA_BLOCK.getDefaultState();
        return Blocks.OBSIDIAN.getDefaultState();
    }

    private static void set(StructureWorldAccess w, BlockPos p, BlockState s) {
        w.setBlockState(p, s, Block.NOTIFY_LISTENERS);
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> ctx) {
        StructureWorldAccess w = ctx.getWorld();
        BlockPos o = ctx.getOrigin();
        Random r = ctx.getRandom();
        if (!w.getFluidState(o).isEmpty() || !w.getFluidState(o.down()).isEmpty()) return false;

        final int R = 11;
        final int H = 13;
        int y0 = o.getY();

        // конус
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > R) continue;
                int x = o.getX() + dx;
                int z = o.getZ() + dz;
                int ground = w.getTopY(Heightmap.Type.WORLD_SURFACE_WG, x, z);
                int h = (int) Math.round(H * Math.pow(1.0 - d / R, 0.8));
                int top = y0 + h;
                // чистим деревья/растения над конусом
                for (int y = Math.max(top + 1, ground - 1); y <= ground + 12; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState s = w.getBlockState(p);
                    if (s.isIn(BlockTags.LOGS) || s.isIn(BlockTags.LEAVES) || s.isReplaceable()) set(w, p, Blocks.AIR.getDefaultState());
                }
                for (int y = ground - 2; y <= top; y++) {
                    set(w, new BlockPos(x, y, z), pick(r));
                }
            }
        }

        // пещера-камера
        BlockPos cc = new BlockPos(o.getX(), y0 + 3, o.getZ());
        for (int dx = -5; dx <= 5; dx++) {
            for (int dy = -5; dy <= 5; dy++) {
                for (int dz = -5; dz <= 5; dz++) {
                    if (dx * dx + dy * dy + dz * dz <= 25) set(w, cc.add(dx, dy, dz), Blocks.AIR.getDefaultState());
                }
            }
        }
        // пол камеры
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                if (dx * dx + dz * dz <= 20) {
                    BlockState f = r.nextFloat() < 0.3f ? Blocks.MAGMA_BLOCK.getDefaultState() : Blocks.BASALT.getDefaultState();
                    set(w, new BlockPos(o.getX() + dx, y0 - 2, o.getZ() + dz), f);
                    set(w, new BlockPos(o.getX() + dx, y0 - 3, o.getZ() + dz), Blocks.BLACKSTONE.getDefaultState());
                }
            }
        }
        // лавовые лужицы
        int[][] pools = { { 1, 1 }, { -1, -1 }, { 0, 2 }, { -2, 1 } };
        for (int[] pl : pools) {
            set(w, new BlockPos(o.getX() + pl[0], y0 - 2, o.getZ() + pl[1]), Blocks.LAVA.getDefaultState());
        }
        // вход (туннель на восток)
        for (int dx = 4; dx <= R + 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = -1; dy <= 2; dy++) {
                    set(w, new BlockPos(o.getX() + dx, y0 + dy, o.getZ() + dz), Blocks.AIR.getDefaultState());
                }
            }
            set(w, new BlockPos(o.getX() + dx, y0 - 2, o.getZ()), Blocks.BASALT.getDefaultState());
        }

        // кратер с лавой на вершине
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > 3.0) continue;
                for (int y = y0 + 11; y <= y0 + H + 2; y++) {
                    set(w, new BlockPos(o.getX() + dx, y, o.getZ() + dz), Blocks.AIR.getDefaultState());
                }
                set(w, new BlockPos(o.getX() + dx, y0 + 10, o.getZ() + dz),
                        d <= 2.2 ? Blocks.LAVA.getDefaultState() : Blocks.MAGMA_BLOCK.getDefaultState());
            }
        }

        // монстры
        BlockPos floor = new BlockPos(o.getX(), y0 - 1, o.getZ());
        spawn(w, EntityType.WITHER_SKELETON, floor, true);
        int[][] minions = { { 3, 1 }, { -3, -1 }, { 1, -3 }, { -1, 3 }, { 3, -2 } };
        for (int i = 0; i < minions.length; i++) {
            spawn(w, i % 2 == 0 ? EntityType.BLAZE : EntityType.WITHER_SKELETON,
                    floor.add(minions[i][0], 0, minions[i][1]), false);
        }
        return true;
    }

    private static void spawn(StructureWorldAccess w, EntityType<? extends MobEntity> type, BlockPos pos, boolean boss) {
        MobEntity m = type.create(w.toServerWorld());
        if (m == null) return;
        m.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0f, 0.0f);
        m.initialize(w, w.getLocalDifficulty(pos), SpawnReason.STRUCTURE, null, null);
        m.setPersistent();
        if (boss) {
            m.setCustomName(Text.literal("§6Хранитель вулкана"));
            m.setCustomNameVisible(true);
            m.addCommandTag(BOSS_TAG);
            m.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(120.0);
            m.setHealth(120.0f);
            m.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
            m.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        }
        w.spawnEntity(m);
    }
}
