package com.megautils.world;

import com.megautils.MegaUtils;
import com.mojang.serialization.Codec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/** Ледяной кристалл: высокий шпиль из синего льда с морским фонарём на вершине, иногда со сундуком у подножия. */
public class FrostCrystalFeature extends Feature<DefaultFeatureConfig> {
    public FrostCrystalFeature(Codec<DefaultFeatureConfig> codec) { super(codec); }

    private static void set(StructureWorldAccess w, BlockPos p, BlockState s) {
        w.setBlockState(p, s, Block.NOTIFY_LISTENERS);
    }

    private static void spire(StructureWorldAccess w, Random r, BlockPos base, int height, boolean thick) {
        for (int h = 0; h < height; h++) {
            boolean wide = thick && h < height * 0.55;
            BlockState s = r.nextFloat() < 0.3f ? Blocks.PACKED_ICE.getDefaultState() : Blocks.BLUE_ICE.getDefaultState();
            set(w, base.up(h), s);
            if (wide) {
                set(w, base.up(h).north(), s);
                set(w, base.up(h).south(), s);
                set(w, base.up(h).east(), s);
                set(w, base.up(h).west(), s);
            }
        }
        set(w, base.up(height), Blocks.SEA_LANTERN.getDefaultState());
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> ctx) {
        StructureWorldAccess w = ctx.getWorld();
        BlockPos o = ctx.getOrigin();
        Random r = ctx.getRandom();
        if (!w.getFluidState(o).isEmpty() || !w.getFluidState(o.down()).isEmpty()) return false;

        spire(w, r, o, 9 + r.nextInt(6), true);
        int extra = 3 + r.nextInt(3);
        for (int i = 0; i < extra; i++) {
            int dx = r.nextInt(9) - 4;
            int dz = r.nextInt(9) - 4;
            if (Math.abs(dx) < 2 && Math.abs(dz) < 2) continue;
            BlockPos b = o.add(dx, 0, dz);
            if (w.getBlockState(b).isAir() && !w.getBlockState(b.down()).isAir()) {
                spire(w, r, b, 3 + r.nextInt(4), false);
            }
        }
        if (r.nextFloat() < 0.4f) {
            BlockPos cp = o.add(3, 0, 0);
            if (w.getBlockState(cp).isAir()) {
                set(w, cp, Blocks.CHEST.getDefaultState().with(ChestBlock.FACING, Direction.Type.HORIZONTAL.random(r)));
                LootableContainerBlockEntity.setLootTable(w, r, cp, new Identifier(MegaUtils.MODID, "chests/frozen"));
            }
        }
        return true;
    }
}
