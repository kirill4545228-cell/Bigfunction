package com.megautils.world;

import com.megautils.MegaUtils;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

/** Смерть Хранителя вулкана -> появляется сундук с наградой. */
public final class WorldEvents {
    private WorldEvents() { }

    public static void init() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity.getWorld() instanceof ServerWorld sw && entity.getCommandTags().contains(VolcanoFeature.BOSS_TAG)) {
                BlockPos bp = entity.getBlockPos();
                for (int i = 0; i < 4 && !sw.getBlockState(bp).isAir(); i++) bp = bp.up();
                sw.setBlockState(bp, Blocks.CHEST.getDefaultState());
                LootableContainerBlockEntity.setLootTable(sw, sw.random, bp, new Identifier(MegaUtils.MODID, "chests/volcano"));
                ExperienceOrbEntity.spawn(sw, entity.getPos(), 300);
                sw.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, entity.getX(), entity.getY() + 1, entity.getZ(), 60, 0.6, 0.8, 0.6, 0.3);
                for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.squaredDistanceTo(entity) < 4096.0)) {
                    p.sendMessage(Text.literal("§6Хранитель вулкана повержен! Награда ждёт тебя."));
                }
            }
            return true;
        });
    }
}
