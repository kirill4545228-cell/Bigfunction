package com.megautils.world;

import com.megautils.MegaUtils;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.PlacedFeature;

public final class ModWorldgen {
    public static final Feature<DefaultFeatureConfig> METEORITE = Registry.register(Registries.FEATURE,
            new Identifier(MegaUtils.MODID, "meteorite"), new MeteoriteFeature(DefaultFeatureConfig.CODEC));
    public static final Feature<DefaultFeatureConfig> VOLCANO = Registry.register(Registries.FEATURE,
            new Identifier(MegaUtils.MODID, "volcano"), new VolcanoFeature(DefaultFeatureConfig.CODEC));
    public static final Feature<DefaultFeatureConfig> FROST_CRYSTAL = Registry.register(Registries.FEATURE,
            new Identifier(MegaUtils.MODID, "frost_crystal"), new FrostCrystalFeature(DefaultFeatureConfig.CODEC));

    private static RegistryKey<PlacedFeature> key(String name) {
        return RegistryKey.of(RegistryKeys.PLACED_FEATURE, new Identifier(MegaUtils.MODID, name));
    }

    public static void init() {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Feature.SURFACE_STRUCTURES, key("meteorite"));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Feature.SURFACE_STRUCTURES, key("volcano"));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(BiomeKeys.SNOWY_PLAINS, BiomeKeys.SNOWY_TAIGA,
                        BiomeKeys.ICE_SPIKES, BiomeKeys.GROVE, BiomeKeys.SNOWY_SLOPES),
                GenerationStep.Feature.SURFACE_STRUCTURES, key("frost_crystal"));
    }
}
