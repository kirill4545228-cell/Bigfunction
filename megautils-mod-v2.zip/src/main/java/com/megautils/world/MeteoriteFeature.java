package com.megautils.world;

import com.megautils.MegaUtils;
import com.megautils.block.ModBlocks;
import com.mojang.serialization.Codec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/** Кратер от упавшего метеорита: обожжённая земля, метеоритная руда и сундук на дне. */
public class MeteoriteFeature extends Feature<DefaultFeatureConfig> {
    public MeteoriteFeature(Codec<DefaultFeatureConfig> codec) { super(codec); }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> ctx) {
        StructureWorldAccess w = ctx.getWorld();
        BlockPos o = ctx.getOrigin();
        Random r = ctx.getRandom();
        if (!w.getFluidState(o).isEmpty() || !w.getFluidState(o.down()).isEmpty()) return false;

        int radius = 4 + r.nextInt(2);
        BlockPos c = o.down(1);

        // убираем растительность над кратером
        for (int dx = -radius - 1; dx <= radius + 1; dx++) {
            for (int dz = -radius - 1; dz <= radius + 1; dz++) {
                if (dx * dx + dz * dz > (radius + 1) * (radius + 1)) continue;
                for (int dy = 0; dy <= 10; dy++) {
                    BlockPos p = o.add(dx, dy, dz);
                    BlockState s = w.getBlockState(p);
                    if (!s.isAir() && s.getFluidState().isEmpty()) w.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            }
        }

        // чаша кратера + обожжённая оболочка
        for (int dx = -radius - 2; dx <= radius + 2; dx++) {
            for (int dy = -radius - 2; dy <= radius + 2; dy++) {
                for (int dz = -radius - 2; dz <= radius + 2; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy * 1.2 + dz * dz);
                    BlockPos p = c.add(dx, dy, dz);
                    if (d <= radius) {
                        w.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                    } else if (d <= radius + 1.6 && dy <= 1) {
                        BlockState s = w.getBlockState(p);
                        if (s.isAir() || !s.getFluidState().isEmpty()) continue;
                        float f = r.nextFloat();
                        BlockState rim = f < 0.45f ? Blocks.BLACKSTONE.getDefaultState()
                                : f < 0.7f ? Blocks.COBBLED_DEEPSLATE.getDefaultState()
                                : f < 0.85f ? Blocks.MAGMA_BLOCK.getDefaultState()
                                : f < 0.95f ? Blocks.COARSE_DIRT.getDefaultState()
                                : Blocks.OBSIDIAN.getDefaultState();
                        w.setBlockState(p, rim, Block.NOTIFY_LISTENERS);
                    }
                }
            }
        }

        // ядро метеорита и сундук
        int floorY = c.getY() - radius + 1;
        BlockPos center = new BlockPos(c.getX(), floorY, c.getZ());
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockPos p = center.add(dx, -1, dz);
                if ((dx == 0 && dz == 0) || r.nextFloat() < 0.65f) {
                    w.setBlockState(p, ModBlocks.METEORITE_ORE.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
                BlockPos q = center.add(dx, 0, dz);
                if ((dx != 0 || dz != 0) && r.nextFloat() < 0.35f) {
                    w.setBlockState(q, ModBlocks.METEORITE_ORE.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            }
        }
        w.setBlockState(center, Blocks.CHEST.getDefaultState()
                .with(ChestBlock.FACING, Direction.Type.HORIZONTAL.random(r)), Block.NOTIFY_LISTENERS);
        LootableContainerBlockEntity.setLootTable(w, r, center, new Identifier(MegaUtils.MODID, "chests/meteorite"));
        return true;
    }
}
