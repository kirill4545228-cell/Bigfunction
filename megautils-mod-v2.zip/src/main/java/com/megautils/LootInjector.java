package com.megautils;

import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.function.SetNbtLootFunction;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;

/** Во все сундуки структур (chests/*) с шансом 30% добавляется книга с одним из наших зачарований. */
public final class LootInjector {
    private LootInjector() { }

    public static void init() {
        LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
            if (!source.isBuiltin() || !id.getPath().startsWith("chests/")) return;
            LootPool.Builder pool = LootPool.builder()
                    .rolls(ConstantLootNumberProvider.create(1))
                    .conditionally(RandomChanceLootCondition.builder(0.3f));
            for (ModEnchantments.Entry e : ModEnchantments.ALL) {
                int max = e.enchantment().getMaxLevel();
                for (int l = 1; l <= max; l++) {
                    NbtCompound tag = new NbtCompound();
                    NbtList list = new NbtList();
                    list.add(EnchantmentHelper.createNbt(e.id(), l));
                    tag.put("StoredEnchantments", list);
                    pool.with(ItemEntry.builder(Items.ENCHANTED_BOOK)
                            .weight(max - l + 1)
                            .apply(SetNbtLootFunction.builder(tag)));
                }
            }
            tableBuilder.pool(pool);
            LootPool.Builder seeds = LootPool.builder()
                    .rolls(ConstantLootNumberProvider.create(1))
                    .conditionally(RandomChanceLootCondition.builder(0.25f));
            for (net.minecraft.item.Item it : new net.minecraft.item.Item[] {
                    com.megautils.item.ModItems.LUMIBERRY_SEEDS,
                    com.megautils.item.ModItems.EMBER_PEPPER_SEEDS,
                    com.megautils.item.ModItems.FROST_MINT_SEEDS }) {
                seeds.with(ItemEntry.builder(it).apply(
                        SetCountLootFunction.builder(UniformLootNumberProvider.create(1.0f, 3.0f))));
            }
            tableBuilder.pool(seeds);
        });
    }
}
