package com.megautils.mixin;

import com.megautils.ModEnchantments;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.SmeltingRecipe;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import java.util.Optional;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Зачарование «Плавильное касание»: выпадающие предметы сразу переплавляются. */
@Mixin(Block.class)
public class BlockMixin {
    @Inject(
            method = "getDroppedStacks(Lnet/minecraft/block/BlockState;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/entity/BlockEntity;Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;)Ljava/util/List;",
            at = @At("RETURN"),
            cancellable = true)
    private static void megautils$smelt(BlockState state, ServerWorld world, BlockPos pos, BlockEntity be,
                                        Entity entity, ItemStack tool,
                                        CallbackInfoReturnable<List<ItemStack>> cir) {
        if (tool == null || tool.isEmpty() || EnchantmentHelper.getLevel(ModEnchantments.SMELTING, tool) <= 0) return;
        List<ItemStack> result = new ArrayList<>();
        for (ItemStack drop : cir.getReturnValue()) {
            ItemStack one = drop.copy();
            one.setCount(1);
            Optional<SmeltingRecipe> recipe = world.getRecipeManager()
                    .getFirstMatch(RecipeType.SMELTING, new SimpleInventory(one), world);
            if (recipe.isPresent()) {
                ItemStack out = recipe.get().getOutput(world.getRegistryManager()).copy();
                if (!out.isEmpty()) {
                    out.setCount(out.getCount() * drop.getCount());
                    result.add(out);
                    continue;
                }
            }
            result.add(drop);
        }
        cir.setReturnValue(result);
    }
}
