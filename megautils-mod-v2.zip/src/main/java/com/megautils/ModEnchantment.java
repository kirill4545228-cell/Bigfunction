package com.megautils;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.world.ServerWorld;

/** Одно зачарование с настраиваемой целью/уровнем. Получить можно только из сундуков. */
public class ModEnchantment extends Enchantment {
    public enum Kind { NONE, VAMPIRISM, LIGHTNING, FROST, VENOM }

    private final int maxLevel;
    private final Kind kind;

    public ModEnchantment(EnchantmentTarget target, EquipmentSlot[] slots, int maxLevel, Kind kind) {
        super(Rarity.VERY_RARE, target, slots);
        this.maxLevel = maxLevel;
        this.kind = kind;
    }

    @Override public int getMaxLevel() { return maxLevel; }
    @Override public boolean isTreasure() { return true; }
    @Override public boolean isAvailableForRandomSelection() { return false; }
    @Override public boolean isAvailableForEnchantedBookOffer() { return false; }

    @Override
    public void onTargetDamaged(LivingEntity user, Entity target, int level) {
        if (kind == Kind.NONE || user.getWorld().isClient) return;
        switch (kind) {
            case VAMPIRISM -> user.heal(0.5f * level);
            case LIGHTNING -> {
                if (user.getWorld() instanceof ServerWorld sw && sw.random.nextFloat() < 0.15f * level) {
                    LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(sw);
                    if (bolt != null) {
                        bolt.refreshPositionAfterTeleport(target.getX(), target.getY(), target.getZ());
                        sw.spawnEntity(bolt);
                    }
                }
            }
            case FROST -> {
                if (target instanceof LivingEntity le) {
                    le.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40 + 40 * level, level));
                }
            }
            case VENOM -> {
                if (target instanceof LivingEntity le) {
                    le.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 60 * level, 0));
                }
            }
            default -> { }
        }
    }
}
