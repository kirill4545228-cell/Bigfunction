package com.megautils;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.AxeItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/**
 * Срубка дерева (Shift + топор), добыча жилы (Shift + кирка), зона копания (зачарование Экскаватор).
 */
public final class BlockBreakFeatures {
    private static boolean busy = false;
    private static final TagKey<net.minecraft.block.Block> ORES =
            TagKey.of(RegistryKeys.BLOCK, new Identifier("c", "ores"));
    private static final int MAX_LOGS = 256;
    private static final int MAX_ORES = 64;

    private BlockBreakFeatures() { }

    public static void init() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (busy || !(world instanceof ServerWorld sw) || !(player instanceof ServerPlayerEntity sp)) return;
            ItemStack tool = sp.getMainHandStack();
            if (tool.isEmpty()) return;
            busy = true;
            try {
                if (sp.isSneaking()) {
                    if (tool.getItem() instanceof AxeItem && state.isIn(BlockTags.LOGS)) {
                        fellTree(sw, sp, pos);
                    } else if (tool.getItem() instanceof PickaxeItem && isOre(state)) {
                        veinMine(sw, sp, pos, state);
                    }
                } else {
                    int lvl = EnchantmentHelper.getLevel(ModEnchantments.EXCAVATOR, tool);
                    if (tool.isOf(com.megautils.item.ModItems.METEOR_PICKAXE)) lvl = Math.max(lvl, 1);
                    if (lvl > 0 && !(tool.getItem() instanceof HoeItem)) {
                        areaMine(sw, sp, pos, lvl);
                    }
                }
            } finally {
                busy = false;
            }
        });
    }

    private static boolean isOre(BlockState s) {
        if (s.isIn(ORES)) return true;
        String path = Registries.BLOCK.getId(s.getBlock()).getPath();
        return path.endsWith("_ore") || path.equals("ancient_debris");
    }

    private static boolean canContinue(ServerPlayerEntity sp) {
        ItemStack t = sp.getMainHandStack();
        if (t.isEmpty()) return false;
        // не добиваем инструмент до поломки
        return !(t.isDamageable() && t.getMaxDamage() - t.getDamage() <= 2);
    }

    private static List<BlockPos> flood(ServerWorld w, BlockPos start, Predicate<BlockState> match, int limit) {
        Set<BlockPos> seen = new HashSet<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        List<BlockPos> result = new ArrayList<>();
        seen.add(start);
        queue.add(start);
        while (!queue.isEmpty() && result.size() < limit) {
            BlockPos cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        BlockPos n = cur.add(dx, dy, dz);
                        if (seen.add(n) && match.test(w.getBlockState(n))) {
                            result.add(n);
                            queue.add(n);
                            if (result.size() >= limit) return result;
                        }
                    }
                }
            }
        }
        return result;
    }

    private static void fellTree(ServerWorld w, ServerPlayerEntity sp, BlockPos origin) {
        List<BlockPos> logs = flood(w, origin, s -> s.isIn(BlockTags.LOGS), MAX_LOGS);
        if (logs.isEmpty()) return;
        // рубим только натуральные деревья (рядом есть непоставленная игроком листва), чтобы не сносить дома
        boolean natural = false;
        for (BlockPos p : logs) {
            if (hasNaturalLeaves(w, p)) { natural = true; break; }
        }
        if (!natural) return;
        for (BlockPos p : logs) {
            if (!canContinue(sp)) break;
            sp.interactionManager.tryBreakBlock(p);
        }
    }

    private static boolean hasNaturalLeaves(ServerWorld w, BlockPos p) {
        for (Direction d : Direction.values()) {
            BlockState s = w.getBlockState(p.offset(d));
            if (s.getBlock() instanceof LeavesBlock && !s.get(LeavesBlock.PERSISTENT)) return true;
            if (s.isIn(BlockTags.WART_BLOCKS)) return true;
        }
        return false;
    }

    private static void veinMine(ServerWorld w, ServerPlayerEntity sp, BlockPos origin, BlockState state) {
        List<BlockPos> ores = flood(w, origin, s -> s.isOf(state.getBlock()), MAX_ORES);
        for (BlockPos p : ores) {
            if (!canContinue(sp)) break;
            sp.interactionManager.tryBreakBlock(p);
        }
    }

    private static void areaMine(ServerWorld w, ServerPlayerEntity sp, BlockPos origin, int radius) {
        float pitch = sp.getPitch();
        Direction facing = sp.getHorizontalFacing();
        for (int a = -radius; a <= radius; a++) {
            for (int b = -radius; b <= radius; b++) {
                if (a == 0 && b == 0) continue;
                BlockPos p;
                if (Math.abs(pitch) > 50) {
                    p = origin.add(a, 0, b);
                } else if (facing.getAxis() == Direction.Axis.X) {
                    p = origin.add(0, a, b);
                } else {
                    p = origin.add(a, b, 0);
                }
                if (!canContinue(sp)) return;
                ItemStack tool = sp.getMainHandStack();
                BlockState s = w.getBlockState(p);
                if (s.isAir() || s.getHardness(w, p) < 0 || w.getBlockEntity(p) != null || !tool.isSuitableFor(s)) continue;
                sp.interactionManager.tryBreakBlock(p);
            }
        }
    }
}
