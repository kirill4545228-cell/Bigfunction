package com.megautils;

import java.util.List;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/**
 * ПКМ по созревшей культуре = сбор + автопосадка. Мотыга с зачарованием Жнец собирает 3x3 / 5x5.
 * ПКМ семенами по грядке сажает сразу 3x3.
 */
public final class FarmFeatures {
    private FarmFeatures() { }

    public static void init() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || player.isSpectator() || player.isSneaking()) return ActionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockState st = world.getBlockState(pos);
            ItemStack stack = player.getStackInHand(hand);

            if (isMature(st)) {
                if (!world.isClient && world instanceof ServerWorld sw) {
                    int r = stack.getItem() instanceof HoeItem
                            ? EnchantmentHelper.getLevel(ModEnchantments.HARVESTER, stack) : 0;
                    harvest(sw, player, pos, r, stack);
                }
                return ActionResult.SUCCESS;
            }

            if (stack.getItem() instanceof BlockItem bi
                    && (bi.getBlock() instanceof CropBlock || bi.getBlock() instanceof StemBlock)
                    && st.isOf(Blocks.FARMLAND)
                    && hit.getSide() == Direction.UP
                    && world.getBlockState(pos.up()).isAir()) {
                if (!world.isClient && world instanceof ServerWorld sw) {
                    plant(sw, player, pos, stack, bi);
                }
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }

    private static boolean isMature(BlockState s) {
        if (s.getBlock() instanceof CropBlock c) return c.isMature(s);
        return s.isOf(Blocks.NETHER_WART) && s.get(NetherWartBlock.AGE) >= 3;
    }

    private static BlockState youngAgain(BlockState s) {
        if (s.getBlock() instanceof CropBlock c) return c.withAge(0);
        return s.with(NetherWartBlock.AGE, 0);
    }

    private static void harvest(ServerWorld w, PlayerEntity p, BlockPos center, int r, ItemStack tool) {
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                BlockPos pos = center.add(dx, 0, dz);
                BlockState s = w.getBlockState(pos);
                if (!isMature(s)) continue;
                List<ItemStack> drops = Block.getDroppedStacks(s, w, pos, null, p, tool);
                ItemStack seed = s.getBlock().getPickStack(w, pos, s);
                boolean taken = false;
                for (ItemStack d : drops) {
                    // одно семя/клубень уходит на пересадку
                    if (!taken && !d.isEmpty() && ItemStack.areItemsEqual(d, seed)) {
                        d.decrement(1);
                        taken = true;
                    }
                    if (!d.isEmpty()) Block.dropStack(w, pos, d);
                }
                w.setBlockState(pos, youngAgain(s), Block.NOTIFY_ALL);
                w.playSound(null, pos, SoundEvents.ITEM_CROP_PLANT, SoundCategory.BLOCKS, 1.0f, 1.0f);
            }
        }
        if (tool.getItem() instanceof HoeItem) {
            tool.damage(1, p, e -> e.sendToolBreakStatus(Hand.MAIN_HAND));
        }
    }

    private static void plant(ServerWorld w, PlayerEntity p, BlockPos center, ItemStack stack, BlockItem item) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (stack.isEmpty() && !p.isCreative()) return;
                BlockPos farm = center.add(dx, 0, dz);
                BlockPos above = farm.up();
                if (!w.getBlockState(farm).isOf(Blocks.FARMLAND) || !w.getBlockState(above).isAir()) continue;
                BlockState ns = item.getBlock().getDefaultState();
                if (!ns.canPlaceAt(w, above)) continue;
                w.setBlockState(above, ns);
                w.playSound(null, above, SoundEvents.ITEM_CROP_PLANT, SoundCategory.BLOCKS, 1.0f, 1.0f);
                if (!p.isCreative()) stack.decrement(1);
            }
        }
    }
}
