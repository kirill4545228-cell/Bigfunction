package com.megautils;

import java.util.List;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Постоянные эффекты зачарований (раз в N тиков). */
public final class EnchantEffects {
    private EnchantEffects() { }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.getTicks();
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.isSpectator()) continue;
                if (t % 2 == 0) magnet(p);
                if (t % 20 == 0) effects(p);
                if (t % 100 == 0) regrow(p);
            }
        });
    }

    private static int lvl(Enchantment e, ItemStack s) {
        return s.isEmpty() ? 0 : EnchantmentHelper.getLevel(e, s);
    }

    private static void apply(ServerPlayerEntity p, StatusEffect effect, int level, int duration) {
        if (level > 0) {
            p.addStatusEffect(new StatusEffectInstance(effect, duration, level - 1, true, false, true));
        }
    }

    private static void effects(ServerPlayerEntity p) {
        ItemStack head = p.getEquippedStack(EquipmentSlot.HEAD);
        ItemStack chest = p.getEquippedStack(EquipmentSlot.CHEST);
        ItemStack feet = p.getEquippedStack(EquipmentSlot.FEET);
        ItemStack hand = p.getMainHandStack();
        apply(p, StatusEffects.NIGHT_VISION, lvl(ModEnchantments.VISION, head), 400);
        apply(p, StatusEffects.WATER_BREATHING, lvl(ModEnchantments.AQUATIC, head), 80);
        apply(p, StatusEffects.FIRE_RESISTANCE, lvl(ModEnchantments.FIREPROOF, chest), 80);
        apply(p, StatusEffects.JUMP_BOOST, lvl(ModEnchantments.LEAPING, feet), 80);
        apply(p, StatusEffects.SPEED, lvl(ModEnchantments.SPRINTER, feet), 80);
        apply(p, StatusEffects.HASTE, lvl(ModEnchantments.HASTE, hand), 80);
    }

    private static void magnet(ServerPlayerEntity p) {
        int l = lvl(ModEnchantments.MAGNET, p.getEquippedStack(EquipmentSlot.HEAD));
        if (l <= 0) return;
        double radius = 1 + 3 * l;
        List<ItemEntity> items = p.getWorld().getEntitiesByClass(
                ItemEntity.class, p.getBoundingBox().expand(radius), e -> !e.cannotPickup());
        Vec3d target = p.getPos().add(0, 0.5, 0);
        for (ItemEntity e : items) {
            Vec3d d = target.subtract(e.getPos());
            if (d.lengthSquared() < 0.25) continue;
            e.setVelocity(d.normalize().multiply(0.35));
            e.velocityModified = true;
        }
    }

    private static void regrow(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty() && s.isDamaged()) {
                int l = EnchantmentHelper.getLevel(ModEnchantments.REGROWTH, s);
                if (l > 0) s.setDamage(Math.max(0, s.getDamage() - l));
            }
        }
    }
}
