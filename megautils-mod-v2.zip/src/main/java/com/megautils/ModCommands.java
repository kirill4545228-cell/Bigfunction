package com.megautils;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** /sethome /home /back /wb /ec /heal /feed /mega + сообщение о координатах смерти. */
public final class ModCommands {
    private ModCommands() { }

    public static void init() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity p) {
                HomeStore.setDeath(p);
                p.sendMessage(Text.literal(String.format("§cВы погибли на X:%d Y:%d Z:%d §7(/back — вернуться)",
                        (int) p.getX(), (int) p.getY(), (int) p.getZ())));
            }
            return true;
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, access, env) -> {
            dispatcher.register(CommandManager.literal("sethome").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                HomeStore.setHome(p);
                ctx.getSource().sendFeedback(() -> Text.literal("§aДом установлен."), false);
                return 1;
            }));

            dispatcher.register(CommandManager.literal("home").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                HomeStore.Home h = HomeStore.getHome(p);
                if (h == null || !HomeStore.teleport(p, h)) {
                    ctx.getSource().sendFeedback(() -> Text.literal("§cДом не установлен (/sethome)."), false);
                    return 0;
                }
                return 1;
            }));

            dispatcher.register(CommandManager.literal("back").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                HomeStore.Home h = HomeStore.getDeath(p);
                if (h == null || !HomeStore.teleport(p, h)) {
                    ctx.getSource().sendFeedback(() -> Text.literal("§cНет точки смерти."), false);
                    return 0;
                }
                return 1;
            }));

            dispatcher.register(CommandManager.literal("wb").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) ->
                        new CraftingScreenHandler(id, inv, ScreenHandlerContext.create(pl.getWorld(), pl.getBlockPos())) {
                            @Override
                            public boolean canUse(PlayerEntity player) { return true; }
                        }, Text.translatable("container.crafting")));
                return 1;
            }));

            dispatcher.register(CommandManager.literal("ec").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                p.openHandledScreen(new SimpleNamedScreenHandlerFactory((id, inv, pl) ->
                        GenericContainerScreenHandler.createGeneric9x3(id, inv, pl.getEnderChestInventory()),
                        Text.translatable("container.enderchest")));
                return 1;
            }));

            dispatcher.register(CommandManager.literal("heal")
                    .requires(src -> src.hasPermissionLevel(2))
                    .executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                        p.setHealth(p.getMaxHealth());
                        p.getHungerManager().add(20, 20.0f);
                        ctx.getSource().sendFeedback(() -> Text.literal("§aВы исцелены."), false);
                        return 1;
                    }));

            dispatcher.register(CommandManager.literal("feed")
                    .requires(src -> src.hasPermissionLevel(2))
                    .executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                        p.getHungerManager().add(20, 20.0f);
                        ctx.getSource().sendFeedback(() -> Text.literal("§aВы сыты."), false);
                        return 1;
                    }));

            dispatcher.register(CommandManager.literal("mega").executes(ctx -> {
                String[] lines = {
                        "§6=== Mega Utils ===",
                        "§eShift + топор §7— срубить всё дерево",
                        "§eShift + кирка §7— вытащить всю жилу руды",
                        "§eПКМ по спелой культуре §7— сбор + автопосадка",
                        "§eПКМ семенами по грядке §7— посадка 3x3",
                        "§eH §7— вкл/выкл информационный HUD",
                        "§e/sethome /home /back /wb /ec /heal /feed",
                        "§dНовое: лейка, жезл телепорта, камень возврата, посох молний, метеоритные инструменты, блок исцеления, 3 новые культуры",
                        "§dМир: метеориты, вулканы с боссом, ледяные кристаллы; красивые дождь, снег и светлячки",
                        "§bЗачарования (только из сундуков): Экскаватор, Плавильное касание, Азарт, Жнец, Магнит,",
                        "§bНочное зрение, Водяные лёгкие, Огнеупорность, Прыгучесть, Спринтер, Вампиризм,",
                        "§bУдар молнии, Стужа, Яд, Самовосстановление"
                };
                for (String l : lines) {
                    ctx.getSource().sendFeedback(() -> Text.literal(l), false);
                }
                return 1;
            }));
        });
    }
}
