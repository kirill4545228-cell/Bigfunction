package com.megautils.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Жезл телепортации: ПКМ — прыжок на 32 блока туда, куда смотришь. */
public class TeleportStaffItem extends Item {
    public TeleportStaffItem(Settings settings) { super(settings); }

    private static boolean free(World w, BlockPos p) {
        return w.getBlockState(p).getCollisionShape(w, p).isEmpty()
                && w.getBlockState(p.up()).getCollisionShape(w, p.up()).isEmpty();
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient || !(world instanceof ServerWorld sw)) return TypedActionResult.success(stack);

        HitResult hit = player.raycast(32.0, 1.0f, false);
        Vec3d dest;
        if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos tp = bhr.getBlockPos().offset(bhr.getSide());
            if (bhr.getSide() == Direction.DOWN) tp = tp.down();
            if (!free(world, tp)) tp = tp.up();
            if (!free(world, tp)) {
                player.sendMessage(Text.literal("§cНет места для телепортации."), true);
                return TypedActionResult.fail(stack);
            }
            dest = Vec3d.ofBottomCenter(tp);
        } else {
            dest = hit.getPos();
        }

        sw.spawnParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 30, 0.3, 0.6, 0.3, 0.2);
        sw.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 1.0f);
        player.requestTeleport(dest.x, dest.y, dest.z);
        player.fallDistance = 0;
        sw.spawnParticles(ParticleTypes.PORTAL, dest.x, dest.y + 1, dest.z, 30, 0.3, 0.6, 0.3, 0.2);
        sw.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 1.2f);
        player.getItemCooldownManager().set(this, 30);
        stack.damage(1, player, e -> e.sendToolBreakStatus(hand));
        return TypedActionResult.success(stack);
    }
}
