package com.megautils.item;

import com.megautils.HomeStore;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Камень возврата: телепорт домой (/sethome), иначе к кровати, иначе на спавн. */
public class RecallStoneItem extends Item {
    public RecallStoneItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient || !(player instanceof ServerPlayerEntity sp) || sp.getServer() == null) {
            return TypedActionResult.success(stack);
        }
        ((ServerWorld) world).spawnParticles(ParticleTypes.REVERSE_PORTAL, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.3, 0.8, 0.3, 0.1);
        HomeStore.Home h = HomeStore.getHome(sp);
        boolean ok = h != null && HomeStore.teleport(sp, h);
        if (!ok) {
            BlockPos s = sp.getSpawnPointPosition();
            ServerWorld w2 = s == null ? null : sp.getServer().getWorld(sp.getSpawnPointDimension());
            if (w2 == null) {
                w2 = sp.getServer().getOverworld();
                s = w2.getSpawnPos();
            }
            sp.teleport(w2, s.getX() + 0.5, s.getY() + 1, s.getZ() + 0.5, sp.getYaw(), sp.getPitch());
        }
        sp.getWorld().playSound(null, sp.getBlockPos(), SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.PLAYERS, 0.4f, 1.5f);
        sp.getItemCooldownManager().set(this, 600);
        stack.damage(1, sp, e -> e.sendToolBreakStatus(hand));
        return TypedActionResult.success(stack);
    }
}
