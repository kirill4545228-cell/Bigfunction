package com.megautils.item;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.Fertilizable;
import net.minecraft.block.FarmlandBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Лейка: поливает грядки 5x5 (увлажняет землю) и ускоряет рост культур — вместо костной муки. */
public class WateringCanItem extends Item {
    public WateringCanItem(Settings settings) { super(settings); }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World w = ctx.getWorld();
        if (w.isClient || !(w instanceof ServerWorld sw)) return ActionResult.SUCCESS;
        PlayerEntity p = ctx.getPlayer();
        BlockPos center = ctx.getBlockPos();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    BlockPos pos = center.add(dx, dy, dz);
                    BlockState st = sw.getBlockState(pos);
                    if (st.isOf(Blocks.FARMLAND) && st.get(FarmlandBlock.MOISTURE) < 7) {
                        sw.setBlockState(pos, st.with(FarmlandBlock.MOISTURE, 7), 2);
                    }
                    Block b = st.getBlock();
                    if ((b instanceof CropBlock || b instanceof StemBlock) && b instanceof Fertilizable f
                            && f.isFertilizable(sw, pos, st, false) && sw.random.nextFloat() < 0.6f) {
                        f.grow(sw, sw.random, pos, st);
                        sw.spawnParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                                5, 0.3, 0.3, 0.3, 0.0);
                    }
                }
            }
        }
        sw.spawnParticles(ParticleTypes.RAIN, center.getX() + 0.5, center.getY() + 2.0, center.getZ() + 0.5,
                40, 1.8, 0.3, 1.8, 0.0);
        sw.playSound(null, center, SoundEvents.ENTITY_PLAYER_SPLASH, SoundCategory.PLAYERS, 0.5f, 1.4f);
        if (p != null) {
            p.getItemCooldownManager().set(this, 15);
            ctx.getStack().damage(1, p, e -> e.sendToolBreakStatus(ctx.getHand()));
        }
        return ActionResult.SUCCESS;
    }
}
