package com.megautils.item;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class MeteorMaterial implements ToolMaterial {
    public static final MeteorMaterial INSTANCE = new MeteorMaterial();

    @Override public int getDurability() { return 2200; }
    @Override public float getMiningSpeedMultiplier() { return 9.0f; }
    @Override public float getAttackDamage() { return 4.0f; }
    @Override public int getMiningLevel() { return 4; }
    @Override public int getEnchantability() { return 18; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(ModItems.METEORITE_INGOT); }
}
