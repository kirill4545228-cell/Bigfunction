package com.megautils.item;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Посох молний: ПКМ — удар молнии в точку прицела (до 40 блоков). */
public class LightningStaffItem extends Item {
    public LightningStaffItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);
        HitResult hit = player.raycast(40.0, 1.0f, false);
        Vec3d pos = hit.getPos();
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
        if (bolt != null) {
            bolt.refreshPositionAfterTeleport(pos);
            if (player instanceof ServerPlayerEntity sp) bolt.setChanneler(sp);
            world.spawnEntity(bolt);
        }
        player.getItemCooldownManager().set(this, 80);
        stack.damage(1, player, e -> e.sendToolBreakStatus(hand));
        return TypedActionResult.success(stack);
    }
}
