package com.megautils.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Метеоритный клинок: поджигает врагов, ПКМ — рывок вперёд. */
public class MeteorSwordItem extends SwordItem {
    public MeteorSwordItem(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.setOnFireFor(5);
        if (target.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.FLAME, target.getX(), target.getY() + 1, target.getZ(), 12, 0.3, 0.5, 0.3, 0.05);
        }
        return super.postHit(stack, target, attacker);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);
        Vec3d look = player.getRotationVec(1.0f);
        player.addVelocity(look.x * 1.8, 0.25, look.z * 1.8);
        player.velocityModified = true;
        player.fallDistance = 0;
        if (player instanceof ServerPlayerEntity sp) {
            sp.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(sp));
            ((ServerWorld) world).spawnParticles(ParticleTypes.FLAME, sp.getX(), sp.getY() + 0.5, sp.getZ(), 25, 0.3, 0.3, 0.3, 0.05);
        }
        player.getItemCooldownManager().set(this, 50);
        stack.damage(2, player, e -> e.sendToolBreakStatus(hand));
        return TypedActionResult.success(stack);
    }
}
