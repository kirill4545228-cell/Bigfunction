package com.megautils.item;

import com.megautils.MegaUtils;
import com.megautils.ModEnchantments;
import com.megautils.block.ModBlocks;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.AliasedBlockItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItems {
    public static final Item METEORITE_INGOT = reg("meteorite_ingot", new Item(new FabricItemSettings().fireproof()));

    public static final Item WATERING_CAN = reg("watering_can", new WateringCanItem(new FabricItemSettings().maxDamage(250)));
    public static final Item TELEPORT_STAFF = reg("teleport_staff", new TeleportStaffItem(new FabricItemSettings().maxDamage(200)));
    public static final Item RECALL_STONE = reg("recall_stone", new RecallStoneItem(new FabricItemSettings().maxDamage(30)));
    public static final Item LIGHTNING_STAFF = reg("lightning_staff", new LightningStaffItem(new FabricItemSettings().maxDamage(150)));
    public static final Item METEOR_SWORD = reg("meteor_sword",
            new MeteorSwordItem(MeteorMaterial.INSTANCE, 3, -2.4f, new FabricItemSettings().fireproof()));
    public static final Item METEOR_PICKAXE = reg("meteor_pickaxe",
            new PickaxeItem(MeteorMaterial.INSTANCE, 1, -2.8f, new FabricItemSettings().fireproof()));

    public static final Item LUMIBERRY_SEEDS = reg("lumiberry_seeds",
            new AliasedBlockItem(ModBlocks.LUMIBERRY_CROP, new FabricItemSettings()));
    public static final Item EMBER_PEPPER_SEEDS = reg("ember_pepper_seeds",
            new AliasedBlockItem(ModBlocks.EMBER_PEPPER_CROP, new FabricItemSettings()));
    public static final Item FROST_MINT_SEEDS = reg("frost_mint_seeds",
            new AliasedBlockItem(ModBlocks.FROST_MINT_CROP, new FabricItemSettings()));

    public static final Item LUMIBERRY = reg("lumiberry", new Item(new FabricItemSettings().food(
            new FoodComponent.Builder().hunger(3).saturationModifier(0.5f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 600), 1.0f).build())));
    public static final Item EMBER_PEPPER = reg("ember_pepper", new Item(new FabricItemSettings().food(
            new FoodComponent.Builder().hunger(4).saturationModifier(0.6f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 800), 1.0f).build())));
    public static final Item FROST_MINT = reg("frost_mint", new Item(new FabricItemSettings().food(
            new FoodComponent.Builder().hunger(2).saturationModifier(0.4f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100), 1.0f).build())));

    public static final Item HEALING_BLOCK = reg("healing_block", new BlockItem(ModBlocks.HEALING_BLOCK, new FabricItemSettings()));
    public static final Item METEORITE_ORE = reg("meteorite_ore", new BlockItem(ModBlocks.METEORITE_ORE, new FabricItemSettings()));

    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP,
            new Identifier(MegaUtils.MODID, "main"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(WATERING_CAN))
                    .displayName(Text.translatable("itemGroup.megautils.main"))
                    .entries((ctx, entries) -> {
                        entries.add(METEORITE_INGOT);
                        entries.add(METEORITE_ORE);
                        entries.add(HEALING_BLOCK);
                        entries.add(WATERING_CAN);
                        entries.add(TELEPORT_STAFF);
                        entries.add(RECALL_STONE);
                        entries.add(LIGHTNING_STAFF);
                        entries.add(METEOR_SWORD);
                        entries.add(METEOR_PICKAXE);
                        entries.add(LUMIBERRY_SEEDS);
                        entries.add(EMBER_PEPPER_SEEDS);
                        entries.add(FROST_MINT_SEEDS);
                        entries.add(LUMIBERRY);
                        entries.add(EMBER_PEPPER);
                        entries.add(FROST_MINT);
                        for (ModEnchantments.Entry e : ModEnchantments.ALL) {
                            for (int l = 1; l <= e.enchantment().getMaxLevel(); l++) {
                                entries.add(EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(e.enchantment(), l)));
                            }
                        }
                    })
                    .build());

    private static Item reg(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(MegaUtils.MODID, name), item);
    }

    public static void init() { }
}
