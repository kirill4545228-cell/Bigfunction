package com.megautils;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MegaUtils implements ModInitializer {
    public static final String MODID = "megautils";
    public static final Logger LOG = LoggerFactory.getLogger(MODID);

    @Override
    public void onInitialize() {
        ModEnchantments.init();
        com.megautils.block.ModBlocks.init();
        com.megautils.item.ModItems.init();
        com.megautils.world.ModWorldgen.init();
        com.megautils.world.WorldEvents.init();
        HomeStore.load();
        BlockBreakFeatures.init();
        FarmFeatures.init();
        EnchantEffects.init();
        LootInjector.init();
        ModCommands.init();
        LOG.info("Mega Utils loaded");
    }
}
