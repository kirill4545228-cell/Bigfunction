package com.megautils;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEnchantments {
    public record Entry(Identifier id, Enchantment enchantment) {}

    public static final List<Entry> ALL = new ArrayList<>();

    private static final EquipmentSlot[] MAIN = { EquipmentSlot.MAINHAND };
    private static final EquipmentSlot[] HEAD = { EquipmentSlot.HEAD };
    private static final EquipmentSlot[] CHEST = { EquipmentSlot.CHEST };
    private static final EquipmentSlot[] FEET = { EquipmentSlot.FEET };

    // Инструменты
    public static final Enchantment EXCAVATOR = reg("excavator", EnchantmentTarget.DIGGER, MAIN, 2, ModEnchantment.Kind.NONE);
    public static final Enchantment SMELTING = reg("smelting", EnchantmentTarget.DIGGER, MAIN, 1, ModEnchantment.Kind.NONE);
    public static final Enchantment HASTE = reg("haste", EnchantmentTarget.DIGGER, MAIN, 2, ModEnchantment.Kind.NONE);
    public static final Enchantment HARVESTER = reg("harvester", EnchantmentTarget.DIGGER, MAIN, 2, ModEnchantment.Kind.NONE);
    // Броня
    public static final Enchantment MAGNET = reg("magnet", EnchantmentTarget.ARMOR_HEAD, HEAD, 3, ModEnchantment.Kind.NONE);
    public static final Enchantment VISION = reg("vision", EnchantmentTarget.ARMOR_HEAD, HEAD, 1, ModEnchantment.Kind.NONE);
    public static final Enchantment AQUATIC = reg("aquatic", EnchantmentTarget.ARMOR_HEAD, HEAD, 1, ModEnchantment.Kind.NONE);
    public static final Enchantment FIREPROOF = reg("fireproof", EnchantmentTarget.ARMOR_CHEST, CHEST, 1, ModEnchantment.Kind.NONE);
    public static final Enchantment LEAPING = reg("leaping", EnchantmentTarget.ARMOR_FEET, FEET, 3, ModEnchantment.Kind.NONE);
    public static final Enchantment SPRINTER = reg("sprinter", EnchantmentTarget.ARMOR_FEET, FEET, 3, ModEnchantment.Kind.NONE);
    // Оружие
    public static final Enchantment VAMPIRISM = reg("vampirism", EnchantmentTarget.WEAPON, MAIN, 3, ModEnchantment.Kind.VAMPIRISM);
    public static final Enchantment LIGHTNING = reg("lightning", EnchantmentTarget.WEAPON, MAIN, 3, ModEnchantment.Kind.LIGHTNING);
    public static final Enchantment FROST = reg("frost", EnchantmentTarget.WEAPON, MAIN, 2, ModEnchantment.Kind.FROST);
    public static final Enchantment VENOM = reg("venom", EnchantmentTarget.WEAPON, MAIN, 2, ModEnchantment.Kind.VENOM);
    // Всё, что ломается
    public static final Enchantment REGROWTH = reg("regrowth", EnchantmentTarget.BREAKABLE, EquipmentSlot.values(), 3, ModEnchantment.Kind.NONE);

    private static Enchantment reg(String name, EnchantmentTarget target, EquipmentSlot[] slots, int max, ModEnchantment.Kind kind) {
        Enchantment e = new ModEnchantment(target, slots, max, kind);
        Identifier id = new Identifier(MegaUtils.MODID, name);
        Registry.register(Registries.ENCHANTMENT, id, e);
        ALL.add(new Entry(id, e));
        return e;
    }

    public static void init() { }
}
