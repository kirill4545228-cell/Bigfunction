package com.megautils.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

/** Информационный HUD: ХП моба, блок под прицелом, координаты, направление, FPS, свет, время. */
public class MegaUtilsClient implements ClientModInitializer {
    private static boolean hudEnabled = true;
    private static KeyBinding toggleKey;
    private static final double RANGE = 24.0;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.megautils.toggle_hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.categories.megautils"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                hudEnabled = !hudEnabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("HUD: " + (hudEnabled ? "вкл" : "выкл")), true);
                }
            }
        });

        HudRenderCallback.EVENT.register(MegaUtilsClient::render);
        AmbientEffects.init();
        net.minecraft.block.Block[] crops = {
                com.megautils.block.ModBlocks.LUMIBERRY_CROP,
                com.megautils.block.ModBlocks.EMBER_PEPPER_CROP,
                com.megautils.block.ModBlocks.FROST_MINT_CROP };
        for (net.minecraft.block.Block b : crops) {
            net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(b, net.minecraft.client.render.RenderLayer.getCutout());
        }
    }

    private static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!hudEnabled || mc.player == null || mc.world == null) return;
        if (mc.options.hudHidden || mc.options.debugEnabled) return;

        // --- левый верхний угол: общая информация ---
        int x = 4, y = 4;
        String dir = switch (mc.player.getHorizontalFacing()) {
            case NORTH -> "Север (-Z)";
            case SOUTH -> "Юг (+Z)";
            case WEST -> "Запад (-X)";
            default -> "Восток (+X)";
        };
        long t = (mc.world.getTimeOfDay() + 6000) % 24000;
        String time = String.format(Locale.ROOT, "%02d:%02d", t / 1000, (t % 1000) * 60 / 1000);
        int light = mc.world.getLightLevel(mc.player.getBlockPos());
        String[] info = {
                String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()),
                "Направление: " + dir,
                "Свет: " + light + "   Время: " + time,
                "FPS: " + mc.getCurrentFps()
        };
        for (String line : info) {
            ctx.drawTextWithShadow(mc.textRenderer, line, x, y, 0xFFFFFF);
            y += 10;
        }

        // --- сверху по центру: цель под прицелом ---
        Entity cam = mc.getCameraEntity();
        if (cam == null) return;
        Vec3d start = cam.getCameraPosVec(tickDelta);
        Vec3d look = cam.getRotationVec(tickDelta);
        Vec3d end = start.add(look.multiply(RANGE));

        HitResult blockHit = cam.raycast(RANGE, tickDelta, false);
        Box box = cam.getBoundingBox().stretch(look.multiply(RANGE)).expand(1.0);
        EntityHitResult entityHit = ProjectileUtil.raycast(cam, start, end, box,
                e -> !e.isSpectator() && e.canHit(), RANGE * RANGE);

        double blockDist = blockHit.getType() == HitResult.Type.BLOCK
                ? blockHit.getPos().squaredDistanceTo(start) : Double.MAX_VALUE;
        double entityDist = entityHit != null ? entityHit.getPos().squaredDistanceTo(start) : Double.MAX_VALUE;

        int cx = ctx.getScaledWindowWidth() / 2;
        int ty = 6;

        if (entityHit != null && entityDist <= blockDist) {
            Entity e = entityHit.getEntity();
            String name = e.getDisplayName().getString();
            drawCentered(ctx, mc, name, cx, ty, 0xFFFFFF);
            if (e instanceof LivingEntity le) {
                float hp = le.getHealth();
                float max = le.getMaxHealth();
                String hpText = String.format(Locale.ROOT, "HP: %.1f / %.1f   Броня: %d", hp, max, le.getArmor());
                drawCentered(ctx, mc, hpText, cx, ty + 11, 0xFF5555);
                int barW = 100;
                int bx = cx - barW / 2;
                int by = ty + 22;
                float ratio = max <= 0 ? 0 : Math.min(1f, hp / max);
                ctx.fill(bx - 1, by - 1, bx + barW + 1, by + 5, 0xFF000000);
                ctx.fill(bx, by, bx + barW, by + 4, 0xFF550000);
                int color = ratio > 0.5f ? 0xFF55FF55 : ratio > 0.25f ? 0xFFFFFF55 : 0xFFFF5555;
                ctx.fill(bx, by, bx + (int) (barW * ratio), by + 4, color);
            }
        } else if (blockHit.getType() == HitResult.Type.BLOCK) {
            BlockHitResult bhr = (BlockHitResult) blockHit;
            BlockState bs = mc.world.getBlockState(bhr.getBlockPos());
            drawCentered(ctx, mc, bs.getBlock().getName().getString(), cx, ty, 0xFFFFFF);
            drawCentered(ctx, mc, Registries.BLOCK.getId(bs.getBlock()).toString(), cx, ty + 11, 0xAAAAAA);
        }
    }

    private static void drawCentered(DrawContext ctx, MinecraftClient mc, String text, int cx, int y, int color) {
        int w = mc.textRenderer.getWidth(text);
        ctx.drawTextWithShadow(mc.textRenderer, text, cx - w / 2, y, color);
    }
}
