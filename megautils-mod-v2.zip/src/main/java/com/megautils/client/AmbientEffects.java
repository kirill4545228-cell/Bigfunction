package com.megautils.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;

/** Красивая погода: снежинки с искрами, дождевые брызги и туман у земли, светлячки ночью. Только клиент. */
public final class AmbientEffects {
    private AmbientEffects() { }

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AmbientEffects::tick);
    }

    private static void tick(MinecraftClient mc) {
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        if (w == null || p == null || mc.isPaused()) return;
        Random r = w.random;
        BlockPos pp = p.getBlockPos();
        float temp = w.getBiome(pp).value().getTemperature();

        if (w.isRaining() && temp < 0.15f) {
            for (int i = 0; i < 8; i++) {
                double x = p.getX() + (r.nextDouble() - 0.5) * 28;
                double z = p.getZ() + (r.nextDouble() - 0.5) * 28;
                double y = p.getY() + 3 + r.nextDouble() * 10;
                if (!w.isSkyVisible(BlockPos.ofFloored(x, y, z))) continue;
                w.addParticle(ParticleTypes.SNOWFLAKE, x, y, z,
                        (r.nextDouble() - 0.5) * 0.03, -0.05 - 0.03 * r.nextDouble(), (r.nextDouble() - 0.5) * 0.03);
            }
            if (r.nextInt(8) == 0) {
                double x = p.getX() + (r.nextDouble() - 0.5) * 20;
                double z = p.getZ() + (r.nextDouble() - 0.5) * 20;
                double y = p.getY() + 1 + r.nextDouble() * 5;
                w.addParticle(ParticleTypes.END_ROD, x, y, z, 0.0, -0.02, 0.0);
            }
        } else if (w.isRaining()) {
            for (int i = 0; i < 6; i++) {
                double x = p.getX() + (r.nextDouble() - 0.5) * 24;
                double z = p.getZ() + (r.nextDouble() - 0.5) * 24;
                int top = w.getTopY(Heightmap.Type.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
                if (Math.abs(top - p.getY()) > 8) continue;
                w.addParticle(ParticleTypes.SPLASH, x, top + 0.1, z, 0.0, 0.0, 0.0);
                if (r.nextInt(12) == 0) {
                    w.addParticle(ParticleTypes.CLOUD, x, top + 0.3, z, 0.0, 0.01, 0.0);
                }
            }
        } else {
            long t = w.getTimeOfDay() % 24000;
            if (t > 13000 && t < 23000 && temp > 0.3f && r.nextInt(3) == 0) {
                double x = p.getX() + (r.nextDouble() - 0.5) * 20;
                double z = p.getZ() + (r.nextDouble() - 0.5) * 20;
                int top = w.getTopY(Heightmap.Type.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
                if (Math.abs(top - p.getY()) <= 6 && w.getBlockState(BlockPos.ofFloored(x, top - 1, z)).isOf(Blocks.GRASS_BLOCK)) {
                    w.addParticle(ParticleTypes.GLOW, x, top + 0.4 + r.nextDouble() * 1.5, z,
                            (r.nextDouble() - 0.5) * 0.02, 0.005, (r.nextDouble() - 0.5) * 0.02);
                }
            }
        }
    }
}
