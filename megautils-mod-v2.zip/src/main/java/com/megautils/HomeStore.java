package com.megautils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

/** Дом (/sethome, /home) хранится в config/megautils_homes.json, точка смерти (/back) — в памяти. */
public final class HomeStore {
    public static class Home {
        public String dim;
        public double x, y, z;
        public float yaw, pitch;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Map<String, Home> homes = new HashMap<>();
    private static final Map<UUID, Home> deaths = new HashMap<>();

    private HomeStore() { }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("megautils_homes.json");
    }

    public static void load() {
        try {
            if (Files.exists(file())) {
                Type type = new TypeToken<Map<String, Home>>() { }.getType();
                Map<String, Home> m = GSON.fromJson(Files.readString(file()), type);
                if (m != null) homes = m;
            }
        } catch (Exception e) {
            MegaUtils.LOG.warn("Не удалось прочитать homes: {}", e.toString());
        }
    }

    private static void save() {
        try {
            Files.writeString(file(), GSON.toJson(homes));
        } catch (Exception e) {
            MegaUtils.LOG.warn("Не удалось сохранить homes: {}", e.toString());
        }
    }

    public static Home of(ServerPlayerEntity p) {
        Home h = new Home();
        h.dim = p.getWorld().getRegistryKey().getValue().toString();
        h.x = p.getX();
        h.y = p.getY();
        h.z = p.getZ();
        h.yaw = p.getYaw();
        h.pitch = p.getPitch();
        return h;
    }

    public static void setHome(ServerPlayerEntity p) {
        homes.put(p.getUuidAsString(), of(p));
        save();
    }

    public static Home getHome(ServerPlayerEntity p) {
        return homes.get(p.getUuidAsString());
    }

    public static void setDeath(ServerPlayerEntity p) {
        deaths.put(p.getUuid(), of(p));
    }

    public static Home getDeath(ServerPlayerEntity p) {
        return deaths.get(p.getUuid());
    }

    public static boolean teleport(ServerPlayerEntity p, Home h) {
        if (p.getServer() == null) return false;
        ServerWorld w = p.getServer().getWorld(RegistryKey.of(RegistryKeys.WORLD, new Identifier(h.dim)));
        if (w == null) return false;
        p.teleport(w, h.x, h.y, h.z, h.yaw, h.pitch);
        return true;
    }
}
