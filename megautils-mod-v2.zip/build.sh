#!/usr/bin/env bash
# Сборка мода: сам скачает Gradle 8.5, создаст gradlew и соберёт jar.
set -e
if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
  echo ">>> Скачиваю Gradle 8.5 для генерации wrapper..."
  curl -sL https://services.gradle.org/distributions/gradle-8.5-bin.zip -o /tmp/gradle.zip
  unzip -q -o /tmp/gradle.zip -d /tmp/gradle-dist
  /tmp/gradle-dist/gradle-8.5/bin/gradle wrapper --gradle-version 8.5 --no-daemon
fi
chmod +x gradlew
./gradlew build --no-daemon
echo ""
echo ">>> ГОТОВО: build/libs/megautils-1.1.0.jar"
ls -la build/libs/
